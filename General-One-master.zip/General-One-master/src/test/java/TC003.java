
public class TC003{
	
	public static void main(String[] args)
	{
		System.out.println("Test case NO 3");
	}
}